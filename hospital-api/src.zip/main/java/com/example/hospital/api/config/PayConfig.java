package com.example.hospital.api.config;

import cn.felord.payment.autoconfigure.EnableMobilePay;
import org.springframework.context.annotation.Configuration;

@EnableMobilePay
@Configuration
public class PayConfig {
}
