package com.example.hospital.api.db.dao;


import com.example.hospital.api.db.pojo.DoctorPrescriptionEntity;

public interface DoctorPrescriptionDao {
    public void insert(DoctorPrescriptionEntity entity);

}

