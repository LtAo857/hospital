package com.example.hospital.api.service;

import java.util.ArrayList;
import java.util.HashMap;

public interface PatientService {
    public ArrayList<HashMap> searchAllPatient();
}
