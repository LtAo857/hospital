package com.example.hospital.api.db.dao;

import java.util.ArrayList;

public interface VideoDiagnoseFileDao {
    public ArrayList<String> searchImageByVideoDiagnoseId(int videoDiagnoseId);
}




