package com.example.hospital.api.db.pojo;

import lombok.Data;

@Data
public class MedicalDeptSubAndDoctorEntity {
    private Integer id;
    private Integer deptSubId;
    private Integer doctorId;

}