package com.example.hospital.api.db.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public interface PatientDao {
    public ArrayList<HashMap> searchAllPatient();
}
